The Bösendorfer SE290 stores each file in a file triple (.KB, .SP, .LP) corresponding to keyboard, soft pedal and loud pedal information. File names mean: 
"moz" for Mozart K.331 1st movement
"etd_bo" for Chopin Etude Op. 10 No. 3
"schub" for Schubert D.783 No. 15
"bal_bo" for Chopin Ballade Op. 38
"bal_kz" for the special version of Chopin Op. 38 (first voice and third voice emphasized)

*.btf is a text version of the Bösendorfer conversion software V30.07 by Wayne Stahnke. 